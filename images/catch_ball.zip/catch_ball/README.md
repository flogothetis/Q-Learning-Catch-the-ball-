******************************
Author: Logothetis Fragkoulis 
Electrical and Computer Engineer
Technical University of Crete 
*******************************


Catch The Ball Game with Q-Learning Algorithm

* Requirements:
Pygame,
Numpy

* To Run:
In a console, go to the project directory and issue: 'python main.py'


